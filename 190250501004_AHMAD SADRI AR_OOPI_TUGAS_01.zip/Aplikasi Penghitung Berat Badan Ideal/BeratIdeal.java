
package ProjectTugas8;

/**
 *
 * @author Ahmad Sadri
 */
public class BeratIdeal {
 private double tb,bb,total;
 private String info;

    public double getTotal() {
        return total = this.bb / (this.tb * this.tb);
    }

    public String getInfo() {
        return info;
    }
 

    public void setTb(double tb) {
        this.tb = tb / 100;
    }

    public void setBb(double bb) {
        this.bb = bb;
    }
    
    void hasil(){
        if (getTotal() < 18.5){
            this.info = "ANDA KURUS";
        }else if (getTotal() < 24.9){
            this.info = "ANDA IDEAL";
        }else if (getTotal() < 29.9){
            this.info = "ANDA OVERWEIGHT";
        }else if (getTotal() > 30.0){
            this.info = "ANDA OBESITAS";    
        }    
    }
         
 
}
